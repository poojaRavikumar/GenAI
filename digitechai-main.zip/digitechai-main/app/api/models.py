# app/api/models.py

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime

# ===================================================================
# DTOs for the Query Processing Endpoint (/ask)
# ===================================================================


class DateRange(BaseModel):
    start: Optional[datetime] = None
    end: Optional[datetime] = None


class QueryFilters(BaseModel):
    document_types: Optional[List[str]] = None
    date_range: Optional[DateRange] = None
    relevance_threshold: Optional[float] = Field(default=0.3, ge=0.0, le=1.0)


class QueryOptions(BaseModel):
    include_sources: bool = True
    max_results: int = Field(default=5, ge=1, le=20)
    response_format: str = Field(default="text", pattern=r"^(text|json)$")


class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=1000)
    context: Optional[str] = Field(None, max_length=2000)
    session_id: Optional[str] = None
    filters: Optional[QueryFilters] = None
    options: Optional[QueryOptions] = QueryOptions()

    # Pydantic validators are class methods, not instance methods.
    # We are telling Pylint to ignore the "no-self-argument" error here.
    @validator('query')
    def validate_query(cls, v):  # pylint: disable=no-self-argument
        if not v.strip():
            raise ValueError('Query cannot be empty or whitespace only')
        return v.strip()


class SourceDocument(BaseModel):
    document_id: str
    title: str
    excerpt: str = Field(..., max_length=500)
    relevance_score: float = Field(..., ge=0.0, le=1.0)
    metadata: Dict[str, Any]


class QueryMetadata(BaseModel):
    processing_time_ms: int
    embedding_time_ms: int
    retrieval_time_ms: int
    generation_time_ms: int
    total_documents_searched: int
    session_id: Optional[str] = None


class QueryResponse(BaseModel):
    response: str
    sources: List[SourceDocument] = []
    query_metadata: QueryMetadata
    confidence_score: float = Field(..., ge=0.0, le=1.0)
    sanitization_applied: bool = False


# ===================================================================
# DTOs for the Document Management Endpoints (/documents/*)
# ===================================================================


class DocumentMetadata(BaseModel):
    author: Optional[str] = None
    created_date: Optional[datetime] = None
    tags: Optional[List[str]] = None
    source_url: Optional[str] = None


class DocumentInput(BaseModel):
    content: str = Field(..., min_length=1)
    title: str = Field(..., min_length=1, max_length=200)
    document_type: str = Field(..., pattern=r"^(pdf|text|web|doc)$")
    metadata: Optional[DocumentMetadata] = None


class DocumentIngestionRequest(BaseModel):
    documents: List[DocumentInput] = Field(..., min_items=1, max_items=100)
    chunk_size: int = Field(default=1000, ge=100, le=2000)
    chunk_overlap: int = Field(default=200, ge=0, le=500)

    # Telling Pylint to ignore the "no-self-argument" error for this validator as well.
    @validator('chunk_overlap')
    def validate_overlap(cls, v, values):  # pylint: disable=no-self-argument
        if 'chunk_size' in values and v >= values['chunk_size']:
            raise ValueError('Chunk overlap must be less than chunk size')
        return v


# ===================================================================
# DTOs for the Health Check Endpoint (/health)
# ===================================================================


class ComponentHealth(BaseModel):
    status: str = Field(..., pattern=r"^(healthy|degraded|unhealthy)$")
    response_time_ms: Optional[int] = None
    additional_info: Optional[Dict[str, Any]] = None


class HealthResponse(BaseModel):
    status: str = Field(..., pattern=r"^(healthy|degraded|unhealthy)$")
    timestamp: datetime
    components: Dict[str, ComponentHealth]
    version: str
    uptime_seconds: int