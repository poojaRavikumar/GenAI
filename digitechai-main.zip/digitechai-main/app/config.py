from pydantic_settings import BaseSettings
from pydantic import Field
from typing import List
from enum import Enum


class Environment(str, Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class OrchestratorConfig(BaseSettings):
    """Configuration for the main orchestrator component"""

    # LLM Configuration
    llm_model_name: str = Field(default="llama3", env="LLM_MODEL_NAME")
    llm_temperature: float = Field(default=0.1, ge=0.0, le=2.0)
    llm_max_tokens: int = Field(default=1000, ge=100, le=4000)
    llm_top_p: float = Field(default=0.9, ge=0.0, le=1.0)

    # Retrieval Configuration
    max_retrieved_docs: int = Field(default=10, ge=1, le=50)
    relevance_threshold: float = Field(default=0.3, ge=0.0, le=1.0)
    enable_reranking: bool = Field(default=True)

    # Caching Configuration
    enable_caching: bool = Field(default=True)
    cache_size: int = Field(default=1000, ge=100)
    cache_ttl_seconds: int = Field(default=3600, ge=300)

    # Performance Configuration
    enable_query_expansion: bool = Field(default=False)
    max_processing_time_seconds: int = Field(default=30, ge=5, le=120)

    # Generation Instructions
    generation_instructions: str = Field(
        default="Provide accurate, helpful responses based on the context."
    )

    class Config:
        env_file = ".env"
        case_sensitive = False


class APIConfig(BaseSettings):
    """Configuration for the API layer"""

    # Server Configuration
    host: str = Field(default="0.0.0.0", env="API_HOST")
    port: int = Field(default=8000, ge=1000, le=65535)
    workers: int = Field(default=4, ge=1, le=16)

    # Security Configuration
    cors_origins: List[str] = Field(default=["*"])
    allowed_hosts: List[str] = Field(default=["*"])
    enable_docs: bool = Field(default=True)

    # Rate Limiting
    rate_limit_requests: int = Field(default=5, ge=1)
    rate_limit_window: str = Field(default="minute")

    # Timeouts
    request_timeout_seconds: int = Field(default=30, ge=5, le=120)

    # Monitoring
    enable_metrics: bool = Field(default=True)
    metrics_endpoint: str = Field(default="/metrics")

    # Version and Environment
    version: str = Field(default="1.0.0")
    environment: Environment = Field(default=Environment.DEVELOPMENT)

    class Config:
        env_file = ".env"
        case_sensitive = False


class DatabaseConfig(BaseSettings):
    """Configuration for database and vector store"""

    # ChromaDB Configuration
    chroma_persist_directory: str = Field(default="./chroma_db")
    chroma_collection_name: str = Field(default="digiai_documents")

    # Embedding Configuration
    embedding_model: str = Field(default="all-MiniLM-L6-v2")
    embedding_dimension: int = Field(default=384, ge=128, le=1536)

    # Indexing Configuration
    hnsw_m: int = Field(default=16, ge=4, le=64)
    hnsw_ef_construction: int = Field(default=200, ge=100, le=800)
    hnsw_ef_search: int = Field(default=100, ge=50, le=400)

    # Performance Configuration
    batch_size: int = Field(default=32, ge=1, le=128)
    max_concurrent_requests: int = Field(default=10, ge=1, le=50)

    class Config:
        env_file = ".env"
        case_sensitive = False


class SecurityConfig(BaseSettings):
    """Configuration for security and compliance"""

    # API Key Configuration
    api_key_length: int = Field(default=32, ge=16, le=64)
    api_key_prefix: str = Field(default="digiai")

    # PII Detection Configuration
    pii_confidence_threshold: float = Field(default=0.8, ge=0.5, le=1.0)
    pii_entities: List[str] = Field(
        default=[
            "PERSON",
            "EMAIL_ADDRESS",
            "PHONE_NUMBER",
            "SSN",
            "CREDIT_CARD",
        ]
    )

    # Sanitization Configuration
    enable_regex_sanitization: bool = Field(default=True)
    enable_presidio_sanitization: bool = Field(default=True)
    conservative_mode: bool = Field(default=False)

    # Logging Configuration
    log_pii_detections: bool = Field(default=True)
    anonymize_logs: bool = Field(default=True)

    class Config:
        env_file = ".env"
        case_sensitive = False
