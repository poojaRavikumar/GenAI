# app/main.py
from fastapi import FastAPI
from app.api import endpoints
from app.config import APIConfig

# Load configuration
try:
    config = APIConfig()
except Exception:
    class FallbackConfig:
        API_VERSION = "v1"
        enable_docs = True
    config = FallbackConfig()


# Create the FastAPI app instance
app = FastAPI(
    title="DigiAl Intelligent Search Assistant",
    description="Al-powered search and question answering system",
    version=config.API_VERSION,
    docs_url="/docs" if config.enable_docs else None,
    redoc_url="/redoc" if config.enable_docs else None
)

# Include the API routes from the endpoints module
app.include_router(endpoints.router, prefix=f"/api/{config.API_VERSION}")

# A simple root endpoint to confirm the app is running
@app.get("/")
def read_root():
    return {"message": "DigiAI Assistant is running"}